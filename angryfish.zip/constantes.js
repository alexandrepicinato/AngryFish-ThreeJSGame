const background = new Image();
background.src = "./ocean.png";

var can = document.getElementById("stage"),
    ctx = can.getContext('2d'),
    wid = can.width,
    hei = can.height,
    player, floor, pillars, gravity, thrust, running, 
    rainbows, colider, score, gPat, pPat, trans, termVel, pillGap, 
    pillWid, pillSpace, speed, stars, high,
    sprite = document.createElement("img");
sprite.src = "./fish_min.png";
sprite.onload = function(){
    sprite.style.height = 0;
    loop();
};
sprite.width = 36;
sprite.height = 24;


document.body.appendChild(sprite);